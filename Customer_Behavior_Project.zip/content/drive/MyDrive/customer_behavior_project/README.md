
# Customer Behavior Project

This project involves advanced data analysis for customer behavior, predictive modeling, anomaly detection, and simulated cybersecurity analytics. It is designed to reflect the future skills required for data analysts.

## Project Structure

- **data/**: Contains datasets like customers, orders, behavior logs, and simulated attack data.
- **reports/**: Stores generated PDF reports.
- **scripts/**: Contains Python code and Jupyter notebooks.
- **README.md**: This file.
- **requirements.txt**: Python dependencies.

## Key Features

- Predictive analytics (customer churn prediction).
- Anomaly detection in purchasing behavior.
- Simulated cybersecurity scenarios and defense strategies.
- Automated reporting with PDF generation.
